import { Injectable } from '@angular/core';

class Location {
    city: string;
    country: string;
    lat: string;
    lng: string
}
class LocationList {
    data: Array<Location>;
    shouldBeLoaded: number;

}

@Injectable()
export class LocationStorageService {

    constructor() { }

    getLocationsList(): LocationList {
        return JSON.parse(localStorage.getItem('locationsList'));
    }

    saveLocation(location: Location) {
        let list = this.getLocationsList() || { data: [], shouldBeLoaded: -1 };
        if (this.getLocationIndex(location) < 0) {
            list.data.push(location);
            localStorage.setItem('locationsList', JSON.stringify(list));

        }
    }

    areObjectsEqual(obj1, obj2) {
        let keys1 = Object.keys(obj1);
        for (let i in keys1) {
            if (obj1[keys1[i]] != obj2[keys1[i]]) {
                return false;
            }
        };
        return true;
    }

    setLocationFromStorageAttr(location) {
        let list = this.getLocationsList() || { data: [], shouldBeLoaded: -1 };
        list.shouldBeLoaded = this.getLocationIndex(location);
        localStorage.setItem('locationsList', JSON.stringify(list));
    }

    clearLocationFromStorageAttr() {
        let list = this.getLocationsList() || { data: [], shouldBeLoaded: -1 };
        list.shouldBeLoaded = -1;
        localStorage.setItem('locationsList', JSON.stringify(list));
    }
    
    getLocationIndex(location) {
        let list = this.getLocationsList() || { data: [], shouldBeLoaded: -1 };
        for (let i = 0; i < list.data.length; i++) {
            if (this.areObjectsEqual(location, list.data[i])) {
                return i;
            }
        }
        return -1;
    }
    deleteLocation(location) {
        let list = this.getLocationsList();
        list.data.splice(this.getLocationIndex(location), 1);
        localStorage.setItem('locationsList', JSON.stringify(list));
    }

    clearLocations() {
        localStorage.removeItem('locationsList');
    }

}
