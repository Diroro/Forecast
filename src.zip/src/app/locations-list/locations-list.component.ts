import { LocationStorageService } from './../location-storage.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-locations-list',
    templateUrl: './locations-list.component.html',
    styleUrls: ['./locations-list.component.css'],
    providers: [LocationStorageService]
})
export class LocationsListComponent implements OnInit {
    @Input() currentLocation;
    @Output() setCurrentLocation = new EventEmitter();
    locationsList;
    iconSize='small';

    constructor(private ls: LocationStorageService) { }

    ngOnInit() {
        this.getLocationsList();
    }

    getLocationsList() {
        this.locationsList = this.ls.getLocationsList();
    }

    saveLocation() {
        if (this.ls.getLocationIndex(this.currentLocation) == -1) {
            this.ls.saveLocation(this.currentLocation);
            this.getLocationsList();
        }
    }

    chooseLocation(location) {
        this.currentLocation = location;
        this.setCurrentLocation.emit(location);
    }
    deleteLocation() {
        this.ls.deleteLocation(this.currentLocation);
        this.getLocationsList();
    }
}
